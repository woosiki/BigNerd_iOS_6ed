//
//  MapViewController.swift
//  WorldTrotter
//
//  Created by NAVER on 2017. 3. 23..
//  Copyright © 2017년 NAVER. All rights reserved.
//

import UIKit

class MapViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("MapViewController loaded its view.")
    }
}
